//
//  Properties.swift
//  DEGUZMANi95TestApp
//
//  Created by franz.deguzman on 24/06/2017.
//  Copyright © 2017 franz.deguzman. All rights reserved.
//

import Foundation



struct Properties {
    
    struct Color {
        static let darkPrimaryColor  = hexStringToUIColor(hex: "#F57C00")
        static let defaultPrimaryColor = hexStringToUIColor(hex: "#FF9800")
        static let lightPrimaryColor  = hexStringToUIColor(hex: "#FFE0B2")
        static let primaryTextColor  = hexStringToUIColor(hex: "#212121")
        static let secondaryTextColor  = hexStringToUIColor(hex: "#FF5252")
        static let dividerColor   = hexStringToUIColor(hex: "#BDBDBD")
        static let secondaryColor = hexStringToUIColor(hex: "#FF5252")
    }
    
    
    struct API {
        static let getSearchMovies = "https://itunes.apple.com/search"
    }

}
