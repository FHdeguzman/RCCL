//
//  GlobalFunction.swift
//  DEGUZMANi95TestApp
//
//  Created by franz.deguzman on 24/06/2017.
//  Copyright © 2017 franz.deguzman. All rights reserved.
//


import Foundation
import UIKit
import SystemConfiguration


func sendAsychronousRequest(urlString : String, params : String, method: String, completion: @escaping (WebReponse)->()) {
    
    UIApplication.shared.isNetworkActivityIndicatorVisible = true
    print(urlString)
    let url = URL(string: urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
    let session = URLSession.shared
    var request = URLRequest(url: url!)
    
    let data = params.data(using: .utf8)!
    print(params)
    print(data)
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpMethod = method
    request.httpBody = data
    request.timeoutInterval = 300
    
    session.dataTask(with: request, completionHandler: {
        data, response, err in
        
        do{
            if(data != nil){
                let webResponse = WebReponse()
                
                let jsonResult: NSDictionary! = try JSONSerialization.jsonObject(with: data!, options:JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                print(jsonResult)
                
                webResponse.payloadArray = jsonResult["results"] as! NSArray

                completion(webResponse)
            }else{
                completion(WebReponse(success: false))
            }
        }catch{
            completion(WebReponse(success: false))
        }
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }).resume()
    
}

func dateFormatter(dateStr: String) -> String{
    
    let dateFormatter = DateFormatter()
//    let tempLocale = dateFormatter.locale // save locale temporarily
//    dateFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
    let date = dateFormatter.date(from: dateStr)!
    dateFormatter.dateFormat = "MMM dd, yyyy"
//    dateFormatter.locale = tempLocale // reset the locale
    let dateString = dateFormatter.string(from: date)
    
    return dateString
    
}



func showAlertWithTitle(title: String?, andMessage message: String?, withOkButtonTitle ok: String?, andCancelBurronTitle cancel: String?, completion: @escaping (_ returnAlert: UIAlertController, _ returnAlertButtonIndex:Int) -> Void) {
    
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
    var buttonIndex = Int()
    
    if(cancel != nil){
        alert.addAction(UIAlertAction(title: cancel, style: UIAlertActionStyle.cancel, handler:  { action in
            buttonIndex = 1
            completion(alert, buttonIndex)
        }))
    }
    
    if(ok != nil ){
        alert.addAction(UIAlertAction(title: ok, style: UIAlertActionStyle.default, handler: { action in
            buttonIndex = 2
            completion(alert, buttonIndex)
        }))
    }
    
    completion(alert, buttonIndex)
}





