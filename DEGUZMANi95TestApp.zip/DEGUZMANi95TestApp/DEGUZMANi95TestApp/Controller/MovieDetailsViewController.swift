//
//  MovieDetailsViewController.swift
//  DEGUZMANi95TestApp
//
//  Created by franz.deguzman on 24/06/2017.
//  Copyright © 2017 franz.deguzman. All rights reserved.
//

import UIKit

class MovieDetailsViewController: UIViewController {
    @IBOutlet var favoriteBtn: UIButton!
    
    var movieSelected = Movie()

    @IBOutlet var movieImg: UIImageView!
    @IBOutlet var movieTitle: UILabel!
    @IBOutlet var artistName: UILabel!
    @IBOutlet var movieGenre: UILabel!
    @IBOutlet var releaseDate: UILabel!
    @IBOutlet var longDescription: UILabel!
    
    var movieSearchResult = [Movie]()
    
    @IBOutlet var secondViewHeight: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.movieTitle.text = self.movieSelected.trackName
        self.artistName.text = "Artist: \(self.movieSelected.artistName)"
        self.movieGenre.text = "Genre: \(self.movieSelected.primaryGenreName)"
        self.releaseDate.text = "Release Date: \(dateFormatter(dateStr: self.movieSelected.releaseDate))"
        self.longDescription.text = "Description: \(self.movieSelected.longDescription)"
        
        let textSize =  CGSize(width: CGFloat(longDescription.frame.size.width), height: CGFloat(MAXFLOAT))
        let rHeight = lroundf(Float(longDescription.sizeThatFits(textSize).height))
        let charSize = lroundf(Float(longDescription.font.lineHeight))
        let lineCount = rHeight / charSize 
        
        
        self.secondViewHeight.constant = self.secondViewHeight.constant + (CGFloat(lineCount) * self.longDescription.frame.height)
        
        let url = URL(string: self.movieSelected.artworkUrl100.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
        downloadImage(url: url!)
        
        
        if self.movieSelected.isFavorite == true {
            let image = UIImage(named: "favorite_icon_filled")
            favoriteBtn.setImage(image, for: .normal)
        }else{
            let image = UIImage(named: "favorite_icon")
            favoriteBtn.setImage(image, for: .normal)
        }
    }
    
    @IBAction func addToFavorite(_ sender: Any) {

        
        if self.movieSelected.isFavorite == true {
            let image = UIImage(named: "favorite_icon")
            favoriteBtn.setImage(image, for: .normal)
            
            movieSelected.isFavorite = false

        }else{
            let image = UIImage(named: "favorite_icon_filled")
            favoriteBtn.setImage(image, for: .normal)
            
            movieSelected.isFavorite = true
        }
        
        let encodedData = NSKeyedArchiver.archivedData(withRootObject: self.movieSearchResult)
        let userDefaults = UserDefaults.standard
        userDefaults.set(encodedData, forKey: "movieSearchResultDB")
        
    }
    
    
    func downloadImage(url: URL) {
        print("Download Started")
        getDataFromUrl(url: url) { (data, response, error)  in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            DispatchQueue.main.async() { () -> Void in
                self.movieImg.image = UIImage(data: data)
            }
        }
    }

    
    func getDataFromUrl(url: URL, completion: @escaping (_ data: Data?, _  response: URLResponse?, _ error: Error?) -> Void) {
        URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            completion(data, response, error)
            }.resume()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.layer.isHidden = false
        self.tabBarController?.tabBar.tintColor = UIColor.white
        self.tabBarController?.tabBar.barTintColor = Properties.Color.defaultPrimaryColor
        formatNavigationBarController()
    }


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func formatNavigationBarController(){
        self.navigationItem.setHidesBackButton(false, animated: false)
        // Sets the color of the navigation bar and clears the shadow
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = Properties.Color.darkPrimaryColor
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barTintColor = Properties.Color.darkPrimaryColor
    }

}
