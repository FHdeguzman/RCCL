//
//  HomeTableViewController.swift
//  DEGUZMANi95TestApp
//
//  Created by franz.deguzman on 24/06/2017.
//  Copyright © 2017 franz.deguzman. All rights reserved.
//

import UIKit
import SVProgressHUD

class HomeTableViewController: UITableViewController, UISearchResultsUpdating{
    
    var movieSearchResult = [Movie]()
    var movieSelected = Movie()
    var movieStr = String()
     var decodedMovieFromDB = [Movie]()
    var movieSearchResultDB = [Movie]()
    
    let searchController = UISearchController(searchResultsController: nil)
    
    var overlay : UIView?
    
    override func viewDidAppear(_ animated: Bool) {
        if UserDefaults.standard.object(forKey: "movieSearchResultDB") as? Data != nil {
            let decoded  = UserDefaults.standard.data(forKey: "movieSearchResultDB")
            decodedMovieFromDB = NSKeyedUnarchiver.unarchiveObject(with: decoded!) as! [Movie]
            movieSearchResult = decodedMovieFromDB
        }
        self.tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //UserDefaults.standard.removeObject(forKey: "movieSearchResultDB")
        

        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        
        overlay = UIView(frame: view.frame)
        overlay!.backgroundColor = UIColor.lightGray
        overlay!.alpha = 0.9
        
        self.tableView.tableHeaderView = searchController.searchBar
        
        
        
        if currentReachabilityStatus == .notReachable{
            
            showAlertWithTitle(title: nil, andMessage: "Only offline movies are available", withOkButtonTitle: nil, andCancelBurronTitle: "Dismiss"){(returnAlert: UIAlertController,returnAlertButtonIndex:Int) -> Void in
                switch (returnAlertButtonIndex) {
                case 0:
                    self.present(returnAlert, animated: true, completion: nil)
                    break
                case 1:
                    
                    break
                case 2:
                    
                    break
                default:
                    break
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.layer.isHidden = false
        self.tabBarController?.tabBar.tintColor = UIColor.white
        self.tabBarController?.tabBar.barTintColor = Properties.Color.defaultPrimaryColor
        formatNavigationBarController()
    }
    
    @available(iOS 8.0, *)
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchText: searchController.searchBar.text!)
    }
    
    func filterContentForSearchText(searchText: String, scope: String = "All") {
        // do some stuff
        movieStr = searchText
       
        
        if currentReachabilityStatus == .notReachable{
            
            if searchText != "" {
                self.movieSearchResult = self.decodedMovieFromDB.filter( { return $0.trackName.contains(searchText) } )

            }else{
                movieSearchResult = self.decodedMovieFromDB
            }
            self.tableView.reloadData()
        }else{
            if searchText != "" {
                NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(searchMovies), object: nil)
                perform(#selector(searchMovies), with: nil, afterDelay: 1)
            }
        }
    }
    
    func formatNavigationBarController(){
        self.navigationItem.setHidesBackButton(true, animated: false)
        self.title = "Movies"
        // Sets the color of the navigation bar and clears the shadow
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = Properties.Color.darkPrimaryColor
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.barTintColor = Properties.Color.darkPrimaryColor
    }
    
    
    @objc func searchMovies(){
        movieSearchResult.removeAll()
        
        //        UserDefaults.standard.removeObject(forKey: "movieSearchResultDB")
        
        let url = "\(Properties.API.getSearchMovies)?country=PH&entity=movie&term=\(movieStr)"
        print(url)
        
        
        
        sendAsychronousRequest(urlString: url, params: "", method: "GET") { (webReponse) in
            if webReponse.payloadArray.count != 0 {
                
                for i in 0..<webReponse.payloadArray.count {
                    let results = webReponse.payloadArray[i] as! NSDictionary
                    var movieSearched = Movie()

                    movieSearched = Movie(wrapperType: results["wrapperType"] == nil ? "" : results["wrapperType"] as! String, kind: results["kind"] == nil ? "" : results["kind"] as! String, trackId: results["trackId"] == nil ? 0 : results["trackId"] as! NSNumber, trackName: results["trackName"] == nil ? "" : results["trackName"] as! String, trackCensoredName: results["trackCensoredName"] == nil ? "" : results["trackCensoredName"] as! String, trackViewUrl: results["trackViewUrl"] == nil ? "" : results["trackViewUrl"] as! String, previewUrl: results["previewUrl"] == nil ? "" : results["previewUrl"] as! String, artworkUrl30: results["artworkUrl30"] == nil ? "" : results["artworkUrl30"] as! String, artworkUrl60: results["artworkUrl60"] == nil ? "" : results["artworkUrl60"] as! String, artworkUrl100: results["artworkUrl100"] == nil ? "" : results["artworkUrl100"] as! String, collectionPrice: results["collectionPrice"] == nil ? 0 : results["collectionPrice"] as! NSNumber, trackPrice: results["trackPrice"] == nil ? 0 : results["trackPrice"] as! NSNumber, trackRentalPrice: results["trackRentalPrice"] == nil ? 0 : results["trackRentalPrice"] as! NSNumber, collectionHdPrice: results["collectionHdPrice"] == nil ? 0 : results["collectionHdPrice"] as! NSNumber, trackHdPrice: results["trackHdPrice"] == nil ? 0 : results["trackHdPrice"] as! NSNumber, trackHdRentalPrice: results["trackHdRentalPrice"] == nil ?  0 : results["trackHdRentalPrice"] as! NSNumber, releaseDate: results["releaseDate"] == nil ? "" : results["releaseDate"] as! String, collectionExplicitness: results["collectionExplicitness"] == nil ? "" : results["collectionExplicitness"] as! String, trackExplicitness: results["trackExplicitness"] == nil ? "" : results["trackExplicitness"] as! String, trackTimeMillis: results["trackTimeMillis"] == nil ? 0 : results["trackTimeMillis"] as! NSNumber, country: results["country"] == nil ? "" : results["country"] as! String, currency: results["currency"] == nil ? "" : results["currency"] as! String, primaryGenreName: results["primaryGenreName"] == nil ? "" : results["primaryGenreName"] as! String, contentAdvisoryRating: results["contentAdvisoryRating"] == nil ? "" : results["contentAdvisoryRating"] as! String, shortDescription: results["shortDescription"] == nil ? "" : results["shortDescription"] as! String, longDescription: results["longDescription"] == nil ? "" : results["longDescription"] as! String, downloadedImg: movieSearched.downloadedImg, isFavorite: false)

                    
                    DispatchQueue.global(qos: DispatchQoS.background.qosClass).async {
                        do {
                            let imagePath = NSURL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("images/\(movieSearched.trackName)/logo.jpg")
                            
                            let data = try Data(contentsOf: URL(string: movieSearched.artworkUrl100)!)
                            let getImage = UIImage(data: data)
                            try UIImageJPEGRepresentation(getImage!, 100)?.write(to: imagePath!)
                            DispatchQueue.main.async {
                                movieSearched.downloadedImg = getImage!
                                return
                            }
                        }
                        catch {
                            return
                        }
                    }
                    
                    self.movieSearchResult.append(movieSearched)
                    self.movieSearchResultDB.append(movieSearched)
                }
                
                print(self.movieSearchResultDB[0].trackName)
                print(self.movieSearchResultDB.count)
                let encodedData = NSKeyedArchiver.archivedData(withRootObject: self.movieSearchResultDB)
                let userDefaults = UserDefaults.standard
                userDefaults.set(encodedData, forKey: "movieSearchResultDB")
                
                SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.custom)
                SVProgressHUD.setBackgroundColor(Properties.Color.darkPrimaryColor)
                SVProgressHUD.setForegroundColor(UIColor.white)
                SVProgressHUD.setBackgroundLayerColor(Properties.Color.darkPrimaryColor)
                SVProgressHUD.setMinimumDismissTimeInterval(5.0)
                SVProgressHUD.setRingThickness(3.0)
                SVProgressHUD.show()
                self.view.addSubview(self.overlay!)
                self.tableView.isUserInteractionEnabled = false
                self.tableView.reloadData()
            }
            
            
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return movieSearchResult.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "movies", for: indexPath) as! MoviewTableViewCell
        cell.movieTitle.text = self.movieSearchResult[indexPath.row].trackName
        cell.movieGenre.text = "Genre: \(self.movieSearchResult[indexPath.row].primaryGenreName)"
        
        if self.movieSearchResult[indexPath.row].shortDescription == "" {
            cell.movieShortDescription.text = "Description: \(self.movieSearchResult[indexPath.row].longDescription)"
        }else{
            cell.movieShortDescription.text = "Description: \(self.movieSearchResult[indexPath.row].shortDescription)"
        }
        
        
        let url = URL(string: self.movieSearchResult[indexPath.row].artworkUrl100.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
        
        getDataFromUrl(url: url!) { (data, response, error)  in
            guard let data = data, error == nil else { return }
            print("Download Finished")
            DispatchQueue.main.async() { () -> Void in
                cell.movieImg.image = UIImage(data: data)
            }
        }
        
        if self.movieSearchResult[indexPath.row].isFavorite == true {
            let image = UIImage(named: "favorite_icon_filled")
            cell.favoriteBtn.setImage(image, for: .normal)
        }else{
            let image = UIImage(named: "favorite_icon")
            cell.favoriteBtn.setImage(image, for: .normal)
        }
        
        cell.favoriteBtn.tag = indexPath.row
        cell.favoriteBtn.addTarget(self, action: #selector(HomeTableViewController.buttonClicked), for: .touchUpInside)

        DispatchQueue.main.async {
            self.overlay?.removeFromSuperview()
            SVProgressHUD.dismiss()
            self.tableView.isUserInteractionEnabled = true
        }
        
        
        
        return cell
        
        
        
    }
    
    func buttonClicked(sender: UIButton){
        let buttonTag = sender.tag
        movieSearchResult[buttonTag].isFavorite = true
        
        var movieUpdated = Movie()
        movieUpdated = movieSearchResult[buttonTag]
        
        movieSearchResult.remove(at: buttonTag)
        movieSearchResult.insert(movieUpdated, at: buttonTag)
        
        let encodedData = NSKeyedArchiver.archivedData(withRootObject: self.movieSearchResult)
        let userDefaults = UserDefaults.standard
        userDefaults.set(encodedData, forKey: "movieSearchResultDB")
        
        self.tableView.reloadData()
    }
    
    func getDataFromUrl(url: URL, completion: @escaping (_ data: Data?, _  response: URLResponse?, _ error: Error?) -> Void) {
        URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            completion(data, response, error)
            }.resume()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.movieSelected = self.movieSearchResult[indexPath.row]
        
        self.performSegue(withIdentifier: "movieDetails", sender: self)
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        searchController.isActive = false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! MovieDetailsViewController
        vc.movieSelected = movieSelected
        vc.movieSearchResult = movieSearchResult
        
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 200
        
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
