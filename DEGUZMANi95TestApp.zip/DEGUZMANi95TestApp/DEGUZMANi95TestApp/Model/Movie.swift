//
//  Movie.swift
//  DEGUZMANi95TestApp
//
//  Created by franz.deguzman on 24/06/2017.
//  Copyright © 2017 franz.deguzman. All rights reserved.
//

import Foundation
import UIKit


class Movie : NSObject, NSCoding{
    
    var isFavorite = Bool()
    
    var wrapperType = String()
    var kind = String()
    var trackId = NSNumber()
    var artistName = String()
    var trackName = String()
    var trackCensoredName = String()
    var trackViewUrl = String()
    var previewUrl = String()
    var artworkUrl30 = String()
    var artworkUrl60 = String()
    var artworkUrl100 = String()
    var collectionPrice = NSNumber()
    var trackPrice = NSNumber()
    var trackRentalPrice = NSNumber()
    var collectionHdPrice = NSNumber()
    
    var trackHdPrice = NSNumber()
    var trackHdRentalPrice = NSNumber()
    var releaseDate = String()
    
    var collectionExplicitness = String()
    var trackExplicitness = String()
    var trackTimeMillis = NSNumber()
    
    var country = String()
    var currency = String()
    var primaryGenreName = String()
    var contentAdvisoryRating = String()
    var shortDescription = String()
    var longDescription = String()
    
    var downloadedImg = UIImage()
    
    override init(){
        self.downloadedImg = UIImage()
        self.wrapperType = String()
        self.kind = String()
        self.trackId = NSNumber()
        self.trackName = String()
        self.trackCensoredName = String()
        self.trackViewUrl = String()
        self.previewUrl = String()
        self.artworkUrl30 = String()
        self.artworkUrl60 = String()
        self.artworkUrl100 = String()
        
        self.collectionPrice = NSNumber()
        self.trackPrice = NSNumber()
        self.trackRentalPrice = NSNumber()
        self.collectionHdPrice = NSNumber()
        self.trackHdPrice = NSNumber()
        
        self.trackHdRentalPrice = NSNumber()
        self.releaseDate = String()
        self.collectionExplicitness = String()
        
        self.trackExplicitness = String()
        self.trackTimeMillis = NSNumber()
        self.country = String()
        self.currency = String()
        self.primaryGenreName = String()
        self.contentAdvisoryRating = String()
        self.shortDescription = String()
        self.longDescription = String()
        
        self.isFavorite = Bool()
    }
    
    init(wrapperType : String, kind  : String, trackId  : NSNumber, trackName : String, trackCensoredName  : String, trackViewUrl  : String, previewUrl : String, artworkUrl30  : String, artworkUrl60  : String, artworkUrl100 : String, collectionPrice  : NSNumber, trackPrice  : NSNumber, trackRentalPrice : NSNumber, collectionHdPrice  : NSNumber, trackHdPrice  : NSNumber, trackHdRentalPrice : NSNumber, releaseDate  : String, collectionExplicitness  : String, trackExplicitness  : String, trackTimeMillis : NSNumber, country  : String, currency  : String, primaryGenreName : String,  contentAdvisoryRating : String, shortDescription : String, longDescription : String, downloadedImg : UIImage, isFavorite : Bool){
        
        self.downloadedImg = downloadedImg
        self.wrapperType = wrapperType
        self.kind = kind
        self.trackId = trackId
        self.trackName = trackName
        self.trackCensoredName = trackCensoredName
        self.trackViewUrl = trackViewUrl
        self.previewUrl = previewUrl
        self.artworkUrl30 = artworkUrl30
        self.artworkUrl60 = artworkUrl60
        self.artworkUrl100 = artworkUrl100
        
        self.collectionPrice = collectionPrice
        self.trackPrice = trackPrice
        self.trackRentalPrice = trackRentalPrice
        self.collectionHdPrice = collectionHdPrice
        self.trackHdPrice = trackHdPrice
        
        self.trackHdRentalPrice = trackHdRentalPrice
        self.releaseDate = releaseDate
        self.collectionExplicitness = collectionExplicitness
        
        self.trackExplicitness = trackExplicitness
        self.trackTimeMillis = trackTimeMillis
        self.country = country
        self.currency = currency
        self.primaryGenreName = primaryGenreName
        self.contentAdvisoryRating = contentAdvisoryRating
        self.shortDescription = shortDescription
        self.longDescription = longDescription
        self.isFavorite = isFavorite
        
        
    }
    
    required convenience init(coder aDecoder: NSCoder) {
        
        let  wrapperType = aDecoder.decodeObject(forKey: "wrapperType") as! String
        print(wrapperType)
        let  kind = aDecoder.decodeObject(forKey: "kind") as! String
        let  trackId = aDecoder.decodeObject(forKey: "trackId") as! NSNumber
        let  trackName = aDecoder.decodeObject(forKey: "trackName") as! String
        let  trackCensoredName = aDecoder.decodeObject(forKey: "trackCensoredName") as! String
        let  trackViewUrl = aDecoder.decodeObject(forKey: "trackViewUrl") as! String
        let  previewUrl = aDecoder.decodeObject(forKey: "previewUrl") as! String
        let  artworkUrl30 = aDecoder.decodeObject(forKey: "artworkUrl30") as! String
        let  artworkUrl60 = aDecoder.decodeObject(forKey: "artworkUrl60") as! String
        let  artworkUrl100 = aDecoder.decodeObject(forKey: "artworkUrl100") as! String
        let  collectionPrice = aDecoder.decodeObject(forKey: "collectionPrice") as! NSNumber
        let  trackPrice = aDecoder.decodeObject(forKey: "trackPrice") as! NSNumber
        let  trackRentalPrice = aDecoder.decodeObject(forKey: "trackRentalPrice") as! NSNumber
        let  collectionHdPrice = aDecoder.decodeObject(forKey: "collectionHdPrice") as! NSNumber
        let  trackHdPrice = aDecoder.decodeObject(forKey: "trackHdPrice") as! NSNumber
        let  trackHdRentalPrice = aDecoder.decodeObject(forKey: "trackHdRentalPrice") as! NSNumber
        let  releaseDate = aDecoder.decodeObject(forKey: "releaseDate") as! String
        
        let  collectionExplicitness = aDecoder.decodeObject(forKey: "collectionExplicitness") as! String
        let  trackExplicitness = aDecoder.decodeObject(forKey: "trackExplicitness") as! String
        let  trackTimeMillis = aDecoder.decodeObject(forKey: "trackTimeMillis") as! NSNumber
        let  country = aDecoder.decodeObject(forKey: "country") as! String
        let  currency = aDecoder.decodeObject(forKey: "currency") as! String
        let  primaryGenreName = aDecoder.decodeObject(forKey: "primaryGenreName") as! String
        let  contentAdvisoryRating = aDecoder.decodeObject(forKey: "contentAdvisoryRating") as! String
        let  shortDescription = aDecoder.decodeObject(forKey: "shortDescription") as! String
        
        let  longDescription = aDecoder.decodeObject(forKey: "longDescription") as! String
        let  downloadedImg = aDecoder.decodeObject(forKey: "downloadedImg") as! UIImage
        
        
        let  isFavorite = aDecoder.decodeBool(forKey: "isFavorite") as! Bool
        
        self.init(wrapperType : wrapperType, kind  : kind, trackId  : trackId, trackName : trackName, trackCensoredName  : trackCensoredName, trackViewUrl  : trackViewUrl, previewUrl : previewUrl, artworkUrl30  : artworkUrl30, artworkUrl60  : artworkUrl60, artworkUrl100 : artworkUrl100, collectionPrice  : collectionPrice, trackPrice  : trackPrice, trackRentalPrice : trackRentalPrice, collectionHdPrice  : collectionHdPrice, trackHdPrice  : trackHdPrice, trackHdRentalPrice : trackHdRentalPrice, releaseDate  : releaseDate, collectionExplicitness  : collectionExplicitness, trackExplicitness  : trackExplicitness, trackTimeMillis : trackTimeMillis, country  : country, currency  : currency, primaryGenreName : primaryGenreName,  contentAdvisoryRating : contentAdvisoryRating, shortDescription : shortDescription, longDescription : longDescription, downloadedImg : downloadedImg, isFavorite : isFavorite)
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(wrapperType, forKey: "wrapperType")
        aCoder.encode(kind, forKey: "kind")
        aCoder.encode(trackId, forKey: "trackId")
        aCoder.encode(trackName, forKey: "trackName")
        aCoder.encode(trackCensoredName, forKey: "trackCensoredName")
        aCoder.encode(trackViewUrl, forKey: "trackViewUrl")
        aCoder.encode(previewUrl, forKey: "previewUrl")
        aCoder.encode(artworkUrl30, forKey: "artworkUrl30")
        aCoder.encode(artworkUrl60, forKey: "artworkUrl60")
        aCoder.encode(artworkUrl100, forKey: "artworkUrl100")
        aCoder.encode(collectionPrice, forKey: "collectionPrice")
        aCoder.encode(trackPrice, forKey: "trackPrice")
        aCoder.encode(trackRentalPrice, forKey: "trackRentalPrice")
        aCoder.encode(collectionHdPrice, forKey: "collectionHdPrice")
        aCoder.encode(trackHdPrice, forKey: "trackHdPrice")
        aCoder.encode(trackHdRentalPrice, forKey: "trackHdRentalPrice")
        aCoder.encode(releaseDate, forKey: "releaseDate")
        aCoder.encode(collectionExplicitness, forKey: "collectionExplicitness")
        aCoder.encode(trackExplicitness, forKey: "trackExplicitness")
        aCoder.encode(trackTimeMillis, forKey: "trackTimeMillis")
        aCoder.encode(country, forKey: "country")
        aCoder.encode(currency, forKey: "currency")
        aCoder.encode(primaryGenreName, forKey: "primaryGenreName")
        aCoder.encode(contentAdvisoryRating, forKey: "contentAdvisoryRating")
        aCoder.encode(shortDescription, forKey: "shortDescription")
        aCoder.encode(longDescription, forKey: "longDescription")
        aCoder.encode(downloadedImg, forKey: "downloadedImg")
        aCoder.encode(isFavorite, forKey: "isFavorite")
    }
    
}
