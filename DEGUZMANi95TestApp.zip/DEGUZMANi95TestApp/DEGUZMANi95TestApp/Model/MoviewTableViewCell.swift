//
//  MoviewTableViewCell.swift
//  DEGUZMANi95TestApp
//
//  Created by franz.deguzman on 24/06/2017.
//  Copyright © 2017 franz.deguzman. All rights reserved.
//

import Foundation
import UIKit

class MoviewTableViewCell: UITableViewCell {
    
    @IBOutlet var movieImg: UIImageView!
    @IBOutlet var movieTitle: UILabel!
    @IBOutlet var movieGenre: UILabel!
    @IBOutlet var movieShortDescription: UILabel!
    @IBOutlet var favoriteBtn: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
