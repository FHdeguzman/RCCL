//
//  WebReponse.swift
//  DEGUZMANi95TestApp
//
//  Created by franz.deguzman on 24/06/2017.
//  Copyright © 2017 franz.deguzman. All rights reserved.
//

import Foundation

class WebReponse : NSObject{
    
    var success = Bool()
    var payloadDict = NSDictionary()
    var payloadArray = NSArray()
    
    override init(){
        self.success = Bool()
        self.payloadDict = NSDictionary()
        self.payloadArray = NSArray()
    }
    
    init(success : Bool){
        self.success = success
    }
}

